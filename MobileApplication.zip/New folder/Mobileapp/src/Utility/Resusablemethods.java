package Utility;
import java.util.Date;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.touch.offset.PointOption;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.remote.RemoteWebDriver;
import io.appium.java_client.android.AndroidDriver;
import Baseclass.MainDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidElement;

import io.appium.java_client.MultiTouchAction;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import org.openqa.selenium.Dimension;
 
import java.time.Duration;
 
import static io.appium.java_client.touch.TapOptions.tapOptions;
import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;
import static io.appium.java_client.touch.offset.PointOption.point;
import static java.time.Duration.ofMillis;
import static java.time.Duration.ofSeconds;

public class Resusablemethods extends MainDriver {

	public static String textValue = "";
	public static void click(String object){
		//driver.findElement(By.xpath(".//*[@id='account']/a")).click();
		if(driver.findElement(By.xpath(properties.getProperty(object))).isDisplayed()) {
			logger = extent.startTest("Clicked on"+object);
			driver.findElement(By.xpath(properties.getProperty(object))).click();
			 Assert.assertTrue(true);
			 extent.endTest(logger);
			 } 
		else{
			logger.log(LogStatus.FAIL, "Not clicked");
			
		}
			 
		}
	 			
 //click by name
	public static void clickbyname(String object){	
		if(driver.findElementByName(object).isDisplayed()){
			logger = extent.startTest("Clicked on"+object);
			
			driver.findElementByName(object).click();
			Assert.assertTrue(true);
			logger.log(LogStatus.PASS, "Clicked successfully");
			 extent.endTest(logger);			 
			 } 
		else{
			logger.log(LogStatus.FAIL, "Not clicked");			
		}
		    
		}
	
	//click by id
	public void clickbyid(String object){		
	if(driver.findElementById(object).isDisplayed()){
		logger = extent.startTest("Clicked on"+object);		
		driver.findElementById(object).click();
		Assert.assertTrue(true);
		logger.log(LogStatus.PASS, "Clicked successfully");
		 extent.endTest(logger);
		 } 
	else{
		logger.log(LogStatus.FAIL, "Not clicked");
		
	}
	}
		
	//input data by id
	public  void sendkeysbyID(String object,String data){	
		if(driver.findElementById(object).isDisplayed()){
			logger = extent.startTest("Clicked on"+object);		
			driver.findElementById(object).sendKeys(data);
			Assert.assertTrue(true);
			logger.log(LogStatus.PASS, "Clicked successfully");
			 extent.endTest(logger);
			 } 
		else{
			logger.log(LogStatus.FAIL, "Not clicked");			
		}				
		}
	
	//input data by xpath
	public void sendkeysbyxpath(String object,String data){
		
		if(driver.findElementByXPath(object).isDisplayed()){
			logger = extent.startTest("Clicked on"+object);		
			driver.findElementByXPath(object).sendKeys(data);
			Assert.assertTrue(true);
			logger.log(LogStatus.PASS, "Clicked successfully");
			 extent.endTest(logger);
			 } 
		else{
			logger.log(LogStatus.FAIL, "Not clicked");			
		}	
		}
	
	//Click by Xpath
	public void clickbyxpath(String object){
		if(driver.findElementByXPath(object).isDisplayed()){
			logger = extent.startTest("Clicked on"+object);		
			driver.findElementByXPath(object).click();;
			Assert.assertTrue(true);
			logger.log(LogStatus.PASS, "Clicked successfully");
			 extent.endTest(logger);
			 } 
		else{
			logger.log(LogStatus.FAIL, "Not clicked");			
		}	
		
		}
	//send keys by name
	public static void sendkeysbyname(String object,String data){

		if(driver.findElementByName(object).isDisplayed()){
			logger = extent.startTest("Clicked on"+object);		
			driver.findElementByName(object).sendKeys(data);
			Assert.assertTrue(true);
			logger.log(LogStatus.PASS, "Clicked successfully");
			 extent.endTest(logger);
			 } 
		else{
			logger.log(LogStatus.FAIL, "Not clicked");			
		}	
		}
	
	
	
	public String getProductDetails(String object) {
		//String provalue=properties.getProperty("")
		
		try {
			textValue = driver.findElementByXPath(object).getText();
			logger = extent.startTest("Get product Details");	
			if (textValue != null) {
				
				Assert.assertTrue(true);
				logger.log(LogStatus.PASS, "got product details");
				 extent.endTest(logger);
			}
			return textValue;
		} catch (Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false);
			logger.log(LogStatus.FAIL, "Not clicked");	
		}
		return textValue;
	}
		
	
	
	
	
		public void pressByCoordinates (int x, int y, long seconds) {
	        new TouchAction(driver)
	                .press(point(x,y))
	                .waitAction(waitOptions(ofSeconds(seconds)))
	                .release()
	                .perform();
	    }
		
	    public void horizontalSwipeByPercentage (double startPercentage, double endPercentage, double anchorPercentage) {
	        Dimension size = driver.manage().window().getSize();
	        int anchor = (int) (size.height * anchorPercentage);
	        int startPoint = (int) (size.width * startPercentage);
	        int endPoint = (int) (size.width * endPercentage);
	 
	        new TouchAction(driver)
	                .press(point(startPoint, anchor))
	                .waitAction(waitOptions(ofMillis(1000)))
	                .moveTo(point(endPoint, anchor))
	                .release().perform();
	    }
		
		public void swipeByElements (AndroidElement startElement, AndroidElement endElement) {
	        int startX = startElement.getLocation().getX() + (startElement.getSize().getWidth() / 2);
	        int startY = startElement.getLocation().getY() + (startElement.getSize().getHeight() / 2);
	 
	        int endX = endElement.getLocation().getX() + (endElement.getSize().getWidth() / 2);
	        int endY = endElement.getLocation().getY() + (endElement.getSize().getHeight() / 2);
	 
	        new TouchAction(driver)
	                .press(point(startX,startY))
	                .waitAction(waitOptions(ofMillis(1000)))
	                .moveTo(point(endX, endY))
	                .release().perform();
	    }
			
	public static void Tapcoordinates(String object , String data ,String data1)
	{
		try{
			TouchAction Action=new TouchAction(driver);
			int coordinate1 = Integer.parseInt(data);
			int coordinate2 = Integer.parseInt(data1);
			Action.tap(PointOption.point(coordinate1, coordinate2));
			System.out.println("Object Tapped");			
		}
		catch(Exception e){
			System.out.println("Object Tapped");
		}
	}
	
	//adb command to enter text
	public static void adbsendkeys(String data) throws IOException
	{
		try{
			Runtime.getRuntime().exec("adb shell input text"+data );
		}
		catch(Exception e){
	
			System.out.println("Unknown exception");
		}
	}
	//screen rotation
	public void rotate(ScreenOrientation data)
	{
//give portrait or Landscape view in data
		driver.rotate(data);
		driver.getOrientation();
		System.out.println("device rotated");
		
	}
	public void screenshot(String path_screenshot) throws IOException{
		
	    File srcFile=driver.getScreenshotAs(OutputType.FILE);
	    String filename=UUID.randomUUID().toString(); 
	    File targetFile=new File(path_screenshot  + filename +".jpg");
	    FileUtils.copyFile(srcFile,targetFile);
	}
	
	public static void waitFor(String object) throws Exception{
		Thread.sleep(5000);
		}
 
	public static void closeBrowser(){
			driver.quit();
		}
	
	
}

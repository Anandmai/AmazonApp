package Baseclass;

//import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;

public class Samplefile {

		private static AndroidDriver driver;
		public static void main(String[] args) throws MalformedURLException, InterruptedException {

			//File classpathRoot = new File(System.getProperty("user.dir"));
			//File appDir = new File(classpathRoot, "/Apps/Amazon/");
			//File app = new File(appDir, "in.amazon.mShop.android.shopping.apk");

			DesiredCapabilities capabilities = new DesiredCapabilities();
			//capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
			capabilities.setCapability("deviceName", "Galaxy S8");
			capabilities.setCapability("platformVersion", "9");
			capabilities.setCapability("platformName", "Android");
			capabilities.setCapability("udid", "988939415555554f38");
			//capabilities.setCapability("app", app.getAbsolutePath());
			capabilities.setCapability("appPackage", "com.amazon.mShop.android.shopping");
			capabilities.setCapability("appActivity", "com.amazon.mShop.home.HomeActivity");

			driver = new AndroidDriver(new URL("http://localhost:4725/wd/hub"), capabilities);
			Thread.sleep(10000);
			
			
			//String signin = properties.getProperty("SkipSignin");
			
			//driver.findElementByName("JBL C100SI In-Ear Deep Bass Headphones with Mic (Black)").click();
		    driver.findElementById("com.amazon.mShop.android.shopping:id/skip_sign_in_button").click();
		    
		    
            
            
            
			Thread.sleep(10000);
			System.out.println("click success");
			//driver.findElementBy.xpath(“)]”);
			driver.findElementById("com.amazon.mShop.android.shopping:id/rs_search_src_text").click();
			Thread.sleep(10000);
			driver.findElementById("com.amazon.mShop.android.shopping:id/rs_search_src_text").sendKeys("Earphones");
			Thread.sleep(10000);
            driver.findElementByXPath("//*[@resource-id='com.amazon.mShop.android.shopping:id/iss_search_dropdown_item_text']").click();
            Thread.sleep(10000);
           
            driver.findElementByXPath("//*[@resource-id='com.amazon.mShop.android.shopping:id/rs_results_image']").click();
            Thread.sleep(10000);
           // Xpath=//*[contains(@name,'JBL C100SI In-Ear Deep Bass Headphones with Mic (Black)')]
          
            String ele3;
		      ele3 = driver.findElementByXPath("//*[contains(@text,'JBL C100SI In-Ear Deep Bass Headphones with Mic (Black)')]").getText();
		      System.out.println("element:"+ele3);
           /* String ele1="";
            String ele4="";
		      ele1 = driver.findElementByXPath("//*[@class='android.view.View']").getText();
		      ele4  =driver.findElementByXPath("//android.widget.TextView[@text='JBL C100SI In-Ear Deep Bass Headphones with Mic (Black)']").getText();
		      System.out.println("element:"+ele1);
		      System.out.println("element:"+ele4);*/
             // JBL C100SI In-Ear Deep Bass Headphones with Mic (Black)
            Thread.sleep(10000);
            driver.findElementByXPath("//*[@resource-id='a-autoid-2']//*[@class='android.widget.Button']").click();
            Thread.sleep(10000);
			driver.findElementById("com.amazon.mShop.android.shopping:id/action_bar_cart_image").click();
			Thread.sleep(10000);
			
			 String ele2;
		      ele2 = driver.findElementByXPath("//*[contains(@text,'JBL C100SI In-Ear Deep Bass Headphones with Mic (Black)')]").getText();
		      System.out.println("element:"+ele2);
			
		     // ele = driver.findElementByXPath("//*[@content-desc]//*[@class='android.widget.TextView']").getText();
		     // System.out.println("element:"+ele);
		      //if(ele3  == ele2)
		    	  if(ele3.equals(ele2))
		      {
		    	  System.out.println("Pass");
		    }
		    	  else {  
		    		  System.out.println("fail");
		    		  } 
		      
			driver.findElementByXPath("//*[@class='android.widget.Button']").click();
			 
			
			//driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
			
			driver.quit();
			 System.exit(0);
	}

}

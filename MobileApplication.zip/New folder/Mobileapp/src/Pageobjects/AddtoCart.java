package Pageobjects;


import io.appium.java_client.android.AndroidDriver;

import Baseclass.MainDriver;
import org.junit.*;
import java.util.concurrent.TimeUnit;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.xml.DOMConfigurator;
import org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import Utility.ExcelUtils;
import Utility.Resusablemethods;
import Utility.constant;


public class AddtoCart extends MainDriver {
	
	@BeforeTest	
	 public void beforetest() throws Exception {
		System.out.println("Addotcart");
      }
	
	@Test
	public void searchanyproduct()
	{	
		String selectproduct = properties.getProperty("Select_items");
		String selectpro=properties.getProperty("Search_click");
		String add_cart=properties.getProperty("Addtocart");
		String viewcart=properties.getProperty("view_cartbag");
		String productdetails= properties.getProperty("product_details");
		try {					
			Resusablemethods method =new Resusablemethods();
			//Select the product from search list
			method.clickbyxpath(selectproduct);
			Thread.sleep(10000);
			//Click on the Product
			method.clickbyxpath(selectpro);
			Thread.sleep(10000);
			method.screenshot(constant.Screeshot_path);
			//get Product details
			method.getProductDetails(productdetails);
			Thread.sleep(10000);
			//add to cart
			method.clickbyxpath(add_cart);
			Thread.sleep(10000);
			method.screenshot(constant.Screeshot_path);
			//Click on View cart
	       // method.clickbyid(viewcart);
	       // Thread.sleep(10000);		        
			method.screenshot(constant.Screeshot_path);
		}
		
		catch (Exception e) {
			
			e.printStackTrace();
		}
		System.out.println("Product Added to cart Successfully");				
		//Log.info("Click action is performed on Login");
		logger = extent.startTest("passTest");
	    Assert.assertTrue(true);
   	   //To generate the log when the test case is passed
	    logger.log(LogStatus.PASS, "Add to Cart Testcases Passed");
}
	@AfterMethod
	 public void getResult(ITestResult result){
		if(result.getStatus() == ITestResult.FAILURE){
		 logger.log(LogStatus.FAIL, "Test Case Failed is "+result.getName());
		 logger.log(LogStatus.FAIL, "Test Case Failed is "+result.getThrowable());
		 }else if(result.getStatus() == ITestResult.SKIP){
		 logger.log(LogStatus.SKIP, "Test Case Skipped is "+result.getName());
		 
		 }		
		 extent.flush();
     //  driver.close();
		 //extent.endTest(logger);
		 }
	
}

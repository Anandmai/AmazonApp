package Pageobjects;

import io.appium.java_client.android.AndroidDriver;

import Baseclass.MainDriver;
import org.junit.*;
import java.util.concurrent.TimeUnit;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.xml.DOMConfigurator;
import org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import Utility.ExcelUtils;
import Utility.Resusablemethods;
import Utility.constant;


public class CartPage extends MainDriver {
	 String Productincart="";
	@BeforeTest	
	 public void beforetest() throws Exception {
		System.out.println("CartPage");
      }
	
	@Test
	public void searchanyproduct()
	{	
		String Productdetails = properties.getProperty("product_details");		
		String viewcart=properties.getProperty("view_cartbag");
		try {
							
			Resusablemethods method =new Resusablemethods();
		
			
			//Click on View cart
			
	        method.clickbyid(viewcart);     
	        method.screenshot(constant.Screeshot_path);
		     Productincart = driver.findElementByXPath(properties.getProperty(Productdetails)).getText();
		      //Productincart = driver.findElementByXPath("//*[contains(@text,'JBL C100SI In-Ear Deep Bass Headphones with Mic (Black)')]").getText();
		      
		    // if(Productincart == Resusablemethods.textValue) 
		    	 if(Productincart.equals(Resusablemethods.textValue))
		     {
		    	 logger = extent.startTest("selected Product Matched");					
					 Assert.assertTrue(true);
					 logger.log(LogStatus.PASS, "Product Matched");
					 				 
					 } 
				else{
					logger.log(LogStatus.FAIL, "product Not matched");
		     }	        		        
			method.screenshot(constant.Screeshot_path);
		}
		
		catch (Exception e) {		
			e.printStackTrace();
		}
		System.out.println("Product Added to cart Successfully");				
		logger = extent.startTest("passTest");
	    Assert.assertTrue(true);
	    logger.log(LogStatus.PASS, "cart Validation done successfully Testcases Passed");
}
	@AfterMethod
	 public void getResult(ITestResult result){
		if(result.getStatus() == ITestResult.FAILURE){
		 logger.log(LogStatus.FAIL, "Test Case Failed is "+result.getName());
		 logger.log(LogStatus.FAIL, "Test Case Failed is "+result.getThrowable());
		 }else if(result.getStatus() == ITestResult.SKIP){
		 logger.log(LogStatus.SKIP, "Test Case Skipped is "+result.getName());
		 
		 }		
		 extent.flush();
     //  driver.close();
		 //extent.endTest(logger);
		 }
	
}

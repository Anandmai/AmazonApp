package Pageobjects;


import io.appium.java_client.android.AndroidDriver;

import Baseclass.MainDriver;
import org.junit.*;
import java.util.concurrent.TimeUnit;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.xml.DOMConfigurator;
import org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import Utility.ExcelUtils;
import Utility.Resusablemethods;
import Utility.constant;


public class SearchProduct extends MainDriver {
	
	@BeforeTest	
	 public void beforetest() throws Exception {
		System.out.println("Search the Product");
      }
	
	@Test
	public void searchanyproduct()
	{	
		String signin = properties.getProperty("SkipSignin");
		String Search_button=properties.getProperty("Search");
		
		//System.out.println("Value"+signin);
		try {
			ExcelUtils.setExcelFile(constant.Path_TestData + constant.File_TestData,"Test");
			String Productname1 = ExcelUtils.getCellData(1,1);				
			Resusablemethods method =new Resusablemethods();
			//Click on Skip Signin 
			method.screenshot(constant.Screeshot_path);
		      method.clickbyid(signin);
			Thread.sleep(10000);
		//Click on SerachButton
			method.clickbyid(Search_button);
			method.screenshot(constant.Screeshot_path);
			Thread.sleep(10000);
		//Click on SerachButton and Enter the Product
			method.sendkeysbyID(Search_button, Productname1);
			method.screenshot(constant.Screeshot_path);
			
		}
		
		catch (Exception e) {			
			e.printStackTrace();
		}
		System.out.println("Product Searched Successfully");		
		logger = extent.startTest("passTest");
	    Assert.assertTrue(true);
   	   //To generate the log when the test case is passed
	    logger.log(LogStatus.PASS, "Login Testcases Passed");
	    //extent.endTest(logger);
}

	@AfterMethod
	 public void getResult(ITestResult result){
		if(result.getStatus() == ITestResult.FAILURE){
		 logger.log(LogStatus.FAIL, "Test Case Failed is "+result.getName());
		 logger.log(LogStatus.FAIL, "Test Case Failed is "+result.getThrowable());
		 }else if(result.getStatus() == ITestResult.SKIP){
		 logger.log(LogStatus.SKIP, "Test Case Skipped is "+result.getName());
		 
		 }		
		 extent.flush();
      //  driver.close();
		 //extent.endTest(logger);
		 }
}
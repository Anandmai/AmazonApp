package Baseclass;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.classfile.Constant;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.android.AndroidDriver;
import Utility.ExcelUtils;
import Utility.constant;


public class MainDriver {
	
	public static AndroidDriver driver;
	public static ExtentReports extent;
	public static ExtentTest logger;
	public static Properties properties;
	
	private final String andriodproperties= System.getProperty("user.dir")+("\\src\\Utility\\Android.property") ;  
		
	public MainDriver(){
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(andriodproperties));
			properties = new Properties();
			try {
				properties.load(reader);
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();		
			throw new RuntimeException("Configuration.properties not found at " + andriodproperties);
		}
		}		
	
  @BeforeSuite
  public static void beforeSuite() throws Exception {
	 
	   extent = new ExtentReports (System.getProperty("user.dir") +"/test-output/testextentreports.html", true);	
	   extent
					 .addSystemInfo("Host Name", "Amazon App")
				     .addSystemInfo("Environment", "System Integration Testing")
				     .addSystemInfo("User Name", "AnandMai");
	
		 extent.loadConfig(new File(System.getProperty("user.dir")+"\\extent-config.xml"));
		

	
		
		//ExcelUtils.setExcelFile("E:\\New folder\\Mobileapp\\src\\TestData\\",constant.File_TestData);
		
	
	
    	try
		{
    		
								
		   DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability("deviceName", constant.deviceName);
			capabilities.setCapability("platformVersion",constant.platformVersion );
			capabilities.setCapability("platformName", constant.platformName);
			capabilities.setCapability("udid",constant.udid );
			capabilities.setCapability("appPackage", constant.appPackagename);
			capabilities.setCapability("appActivity", constant.appActivityname);

			driver = new AndroidDriver(new URL("http://localhost:4725/wd/hub"), capabilities);
			Thread.sleep(10000);
			driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);	
			
			 }   	 
	
    	catch(Exception e)
		{
			e.printStackTrace();
			return;
		}
}
	@AfterMethod
	 public void getResult(ITestResult result){
		 if(result.getStatus() == ITestResult.FAILURE){
		 logger.log(LogStatus.FAIL, "Test Case Failed is "+result.getName());
		 logger.log(LogStatus.FAIL, "Test Case Failed is "+result.getThrowable());
		 }else if(result.getStatus() == ITestResult.SKIP){
		 logger.log(LogStatus.SKIP, "Test Case Skipped is "+result.getName());
		 }
		 // ending test
		 //endTest(logger) : It ends the current test and prepares to create HTML report
		 extent.endTest(logger);
		 }
	
	public static  void getscreenshot(String Stepname) throws Exception 
   {
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		 String strCurrentTime = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss").format(new Date());
        strCurrentTime=strCurrentTime.replaceAll("\\s","").replaceAll("-","").replaceAll(":","").trim();
        Stepname=Stepname+"_"+strCurrentTime;
        FileHandler.copy(scrFile, new File(constant.Screeshot_path+Stepname+".jpg"));
           
   }
	 
	
	 @AfterSuite
	 public void endReport(){
	                extent.flush();
	                extent.close();
	    }
  
	
    
		
			
  }


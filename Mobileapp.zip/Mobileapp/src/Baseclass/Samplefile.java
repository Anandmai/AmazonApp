package Baseclass;

//import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;

public class Samplefile {

		private static AndroidDriver driver;
		public static void main(String[] args) throws MalformedURLException, InterruptedException {

			//File classpathRoot = new File(System.getProperty("user.dir"));
			//File appDir = new File(classpathRoot, "/Apps/Amazon/");
			//File app = new File(appDir, "in.amazon.mShop.android.shopping.apk");

			DesiredCapabilities capabilities = new DesiredCapabilities();
			//capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
			capabilities.setCapability("deviceName", "Galaxy S8");
			capabilities.setCapability("platformVersion", "9");
			capabilities.setCapability("platformName", "Android");
			capabilities.setCapability("udid", "988939415555554f38");
			//capabilities.setCapability("app", app.getAbsolutePath());
			capabilities.setCapability("appPackage", "com.amazon.mShop.android.shopping");
			capabilities.setCapability("appActivity", "com.amazon.mShop.home.HomeActivity");

			driver = new AndroidDriver(new URL("http://localhost:4725/wd/hub"), capabilities);
			Thread.sleep(10000);
			driver.findElementById("com.amazon.mShop.android.shopping:id/skip_sign_in_button").click();
			//WebElement wb= driver.findElementByXPath("//android.widget.EditText[contains(@resource-id,'com.amazon.mShop.android.shopping:id/rs_search_src_text′)");
//System.out.println("webe"+wb);
			Thread.sleep(10000);
			System.out.println("click success");
			//driver.findElementBy.xpath(“)]”);
			driver.findElementById("com.amazon.mShop.android.shopping:id/rs_search_src_text").click();
			Thread.sleep(10000);
			driver.findElementById("com.amazon.mShop.android.shopping:id/rs_search_src_text").sendKeys("Earphones");
driver.findElementByXPath("//*[@resource-id='com.amazon.mShop.android.shopping:id/iss_search_dropdown_item_text']").click();
			
			System.out.println("click success");
			//driver.findElementByXPath("//*[@resource-id='com.amazon.mShop.android.shopping:id/skip_sign_in_button']").click();
		//	WebElement wb = 
		//	wb.click();
			
			//("//*[@resource-id='com.amazon.mShop.android.shopping:id/iss_search_dropdown_item_text']").click();
			
			//driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
			
			driver.quit();

	}

}

package Utility;

public class constant {
	public static final String deviceName="Galaxy S8";
	public static final String platformVersion="9";
	public static final String platformName="Android";
	public static final String udid="988939415555554f38";
	
	 public static final String appPackagename="com.amazon.mShop.android.shopping";
	 public static final String appActivityname="com.amazon.mShop.home.HomeActivity";
	       public static final String Screeshot_path = "E:\\New folder\\screenshots";
	       public static final String Path_TestData = "E:\\New folder\\Mobileapp\\src\\"	;
	       //"E:\New folder\Mobileapp\src\TestData.xlsx"
	      
	      public static final String File_TestData = "TestData.xlsx";
	      
}

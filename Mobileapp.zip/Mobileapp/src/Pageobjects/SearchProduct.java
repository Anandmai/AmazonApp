package Pageobjects;


import io.appium.java_client.android.AndroidDriver;

import Baseclass.MainDriver;
import org.junit.*;
import java.util.concurrent.TimeUnit;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.xml.DOMConfigurator;
import org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import Utility.ExcelUtils;
import Utility.constant;
public class SearchProduct extends MainDriver {
	 
	@BeforeTest	
	 public void beforetest() throws Exception {
		System.out.println("Search the Product");
      }

	@Test
	public void searchanyproduct()
	{
		
		String signin = properties.getProperty("SkipSignin");
		System.out.println("Value"+signin);
		try {
			ExcelUtils.setExcelFile(constant.Path_TestData + constant.File_TestData,"Test");
			String Productname1 = ExcelUtils.getCellData(1,1);
			
			System.out.println("Value:"+Productname1);
			driver.findElementById(properties.getProperty("SkipSignin")).click();
			Thread.sleep(10000);
			driver.findElementById(properties.getProperty("Search")).click();
			Thread.sleep(10000);
			driver.findElementById(properties.getProperty("Search")).sendKeys(Productname1);
			
			Thread.sleep(10000);
			driver.findElementByXPath("//*[@resource-id='com.amazon.mShop.android.shopping:id/iss_search_dropdown_item_text']").click();
			
			//driver.findElementById(properties.getProperty("Select_items")).click();
			
		}
		
		catch (Exception e) {
			
			e.printStackTrace();
		}
		System.out.println("Login Successfully");				
		//Log.info("Click action is performed on Login");
		logger = extent.startTest("passTest");
	    Assert.assertTrue(true);
   	   //To generate the log when the test case is passed
	    logger.log(LogStatus.PASS, "Login Testcases Passed");
}
}
